# Demo data

The CSV files contain fictitious example contacts and reminders. Change the reminder timestamps to a future date/time before trying the live scheduler, or use the dashboard to create a reminder. Do not add real personal contact lists to a public repository.
