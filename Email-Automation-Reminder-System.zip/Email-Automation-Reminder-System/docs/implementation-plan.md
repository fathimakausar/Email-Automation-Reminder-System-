# Proof-of-work plan

| Day | Deliverable | Commit message | Screenshot |
|---|---|---|---|
| 1 | Python environment, folders, API boot | `chore: initialize project structure` | project tree, API docs |
| 2 | Contacts, templates and database models | `feat: add contacts and email templates` | CSV and template |
| 3 | Personalization and dry-run mailer | `feat: personalize email messages` | dry-run output |
| 4 | One-off and recurring reminders | `feat: add recurring reminder worker` | reminders table |
| 5 | Status tracking, logs, CSV export, tests | `feat: add message reporting and tests` | report and test output |
| 6 | Next.js dashboard and docs | `feat: add campaign and reminder dashboard` | dashboard |

Suggested repository: `email-automation-reminder-system`

Description: `Full-stack Python email scheduling and reminder app with FastAPI, SQLite, SMTP dry-run, recurring jobs and Next.js dashboard.`

Topics: `python`, `fastapi`, `email-automation`, `smtp`, `scheduler`, `sqlite`, `nextjs`, `automation`, `portfolio-project`.
