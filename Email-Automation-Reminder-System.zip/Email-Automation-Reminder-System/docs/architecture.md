# Architecture

```text
CSV contacts / Dashboard
          |
          v
       FastAPI <------ Next.js dashboard
          |
          v
   SQLAlchemy + SQLite
    |       |       |
 Contacts Templates Campaigns
              |
           Reminders
              |
              v
        Python worker
              |
        RRULE scheduler
              |
        Jinja2 renderer
              |
        SMTP / Dry-run
              |
              v
        Message status
          /       \
     Dashboard   CSV report
```

The API validates input and persists records. The worker periodically finds due reminders, creates a personalized message, and sends it. Message state and any error are saved in SQLite. The dashboard reads the API to display current totals and records.
\nA personal reminder targets one contact. A team reminder expands the selected team into one reminder per subscribed contact, so each recipient receives an individually personalized message.\n