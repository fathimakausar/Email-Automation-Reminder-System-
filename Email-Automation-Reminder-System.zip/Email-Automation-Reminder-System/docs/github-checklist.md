# GitHub checklist

1. Create a public repository named `email-automation-reminder-system`.
2. Add the description from `implementation-plan.md`.
3. In the project root run:
   ```bash
   git init
   git add .
   git commit -m "chore: initialize email automation project"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/email-automation-reminder-system.git
   git push -u origin main
   ```
4. Use meaningful commits for features and documentation.
5. Add screenshots to `images/` after capturing them locally.
6. Confirm `.env`, SQLite databases, private logs and real contact lists are excluded before pushing.
