# Interview preparation

**30-second explanation:** I built a full-stack email automation and reminder system. Users can manage contacts, create reusable templates and campaigns, schedule one-time or recurring reminders, and monitor message status. Python and FastAPI power the backend, SQLite stores the data, a worker handles scheduled jobs, and a Next.js dashboard provides the interface. Dry-run mode makes it safe to demonstrate without sending real email.

**Problem solved:** It reduces repetitive manual follow-ups for HR, sales, training and operations teams.

**SMTP:** Simple Mail Transfer Protocol, used to send outgoing email.

**FastAPI:** A Python framework for building APIs with request validation and automatic interactive documentation.

**Jinja2:** A template engine that fills placeholders such as `{{ name }}` with contact-specific values.

**RRULE:** A recurrence rule format. For example, `FREQ=WEEKLY;BYDAY=MO` means every Monday.

**Status tracking:** The app stores scheduled, sent or failed state and an error message when sending fails.

**Dry-run:** It simulates a successful send without contacting an email server.

**Limitations:** SMTP acceptance does not guarantee inbox delivery. Actual delivery/bounce tracking needs provider webhooks. This project also needs authentication, unsubscribe/consent controls, retry policies and a durable queue before production use.

**Possible future improvements:** PostgreSQL, Redis/Celery, authentication, role-based access, provider webhooks, rate limits, retries, unsubscribe links, metrics and deployment.
