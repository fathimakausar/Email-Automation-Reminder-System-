from datetime import datetime
from fastapi import FastAPI, Depends, HTTPException
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy.orm import Session
from sqlalchemy import select, func
from src.database import Base, engine, get_db
from src.models import Contact, Template, Campaign, Reminder, Message
from src.logging_config import setup_logging
from src.service import plan_due, dispatch_due

setup_logging()
Base.metadata.create_all(bind=engine)
app = FastAPI(
    title="Email Automation & Reminder System",
    description="Schedule personalized one-off and recurring email reminders.",
    version="1.0.0",
)


class ContactIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    email: EmailStr
    team: str = "General"
    timezone: str = "Asia/Kolkata"


class TemplateIn(BaseModel):
    name: str
    subject: str
    body: str


class CampaignIn(BaseModel):
    name: str
    template_id: int
    sender_name: str = "Automation Team"
    sender_email: EmailStr


class ReminderIn(BaseModel):
    title: str
    contact_id: int
    campaign_id: int
    scheduled_at: datetime
    recurrence: str | None = None


class TeamReminderIn(BaseModel):
    title: str
    team: str
    campaign_id: int
    scheduled_at: datetime
    recurrence: str | None = None


@app.get("/")
def health():
    return {"status": "online", "service": "Email Automation & Reminder System"}


@app.post("/contacts", status_code=201)
def add_contact(data: ContactIn, db: Session = Depends(get_db)):
    email = str(data.email)
    if db.scalar(select(Contact).where(Contact.email == email)):
        raise HTTPException(409, "Contact already exists")
    obj = Contact(**{**data.model_dump(), "email": email})
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return {"id": obj.id, "name": obj.name, "email": obj.email}


@app.get("/contacts")
def list_contacts(db: Session = Depends(get_db)):
    return db.scalars(select(Contact).order_by(Contact.id.desc())).all()


@app.post("/templates", status_code=201)
def add_template(data: TemplateIn, db: Session = Depends(get_db)):
    obj = Template(**data.model_dump())
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return {"id": obj.id, "name": obj.name}


@app.get("/templates")
def list_templates(db: Session = Depends(get_db)):
    return db.scalars(select(Template).order_by(Template.id.desc())).all()


@app.post("/campaigns", status_code=201)
def add_campaign(data: CampaignIn, db: Session = Depends(get_db)):
    if not db.get(Template, data.template_id):
        raise HTTPException(404, "Template not found")
    obj = Campaign(**{**data.model_dump(), "sender_email": str(data.sender_email)})
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return {"id": obj.id, "name": obj.name}


@app.get("/campaigns")
def list_campaigns(db: Session = Depends(get_db)):
    return db.scalars(select(Campaign).order_by(Campaign.id.desc())).all()


@app.post("/reminders", status_code=201)
def add_reminder(data: ReminderIn, db: Session = Depends(get_db)):
    if not db.get(Contact, data.contact_id):
        raise HTTPException(404, "Contact not found")
    if not db.get(Campaign, data.campaign_id):
        raise HTTPException(404, "Campaign not found")
    if data.scheduled_at.tzinfo is None:
        raise HTTPException(422, "scheduled_at must include a timezone offset")
    obj = Reminder(**data.model_dump())
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return {"id": obj.id, "title": obj.title, "scheduled_at": obj.scheduled_at}


@app.post("/team-reminders", status_code=201)
def add_team_reminder(data: TeamReminderIn, db: Session = Depends(get_db)):
    """Create one reminder per subscribed contact in the selected team."""
    if not db.get(Campaign, data.campaign_id):
        raise HTTPException(404, "Campaign not found")
    if data.scheduled_at.tzinfo is None:
        raise HTTPException(422, "scheduled_at must include a timezone offset")
    members = db.scalars(
        select(Contact).where(
            func.lower(Contact.team) == data.team.strip().lower(),
            Contact.unsubscribed.is_(False),
        )
    ).all()
    if not members:
        raise HTTPException(404, "No subscribed contacts found in that team")
    created = []
    for member in members:
        reminder = Reminder(
            title=data.title,
            contact_id=member.id,
            campaign_id=data.campaign_id,
            scheduled_at=data.scheduled_at,
            recurrence=data.recurrence,
        )
        db.add(reminder)
        created.append({"contact": member.email})
    db.commit()
    return {"created": len(created), "team": data.team, "recipients": created}


@app.get("/reminders")
def list_reminders(db: Session = Depends(get_db)):
    return db.scalars(select(Reminder).order_by(Reminder.scheduled_at)).all()


@app.get("/messages")
def list_messages(db: Session = Depends(get_db)):
    return db.scalars(select(Message).order_by(Message.id.desc())).all()


@app.get("/stats")
def stats(db: Session = Depends(get_db)):
    rows = db.scalars(select(Message)).all()
    return {
        "total": len(rows),
        "sent": sum(row.status == "sent" for row in rows),
        "failed": sum(row.status == "failed" for row in rows),
        "scheduled": sum(row.status == "scheduled" for row in rows),
    }


@app.post("/process-due")
def process_due(db: Session = Depends(get_db)):
    """Manually run one scheduler/dispatcher cycle (useful for local demos)."""
    planned = plan_due(db)
    processed = dispatch_due(db)
    return {"planned": planned, "processed": processed}
