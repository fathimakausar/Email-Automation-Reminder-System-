"use client";
import { useEffect, useState } from "react";

const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
type Contact = { id: number; name: string; email: string; team: string };
type Template = { id: number; name: string };
type Campaign = { id: number; name: string; template_id: number };
type Reminder = { id: number; title: string; scheduled_at: string; active: boolean };
type Message = { id: number; contact_email: string; subject: string; status: string; scheduled_at: string; error?: string };

export default function Home() {
  const [stats, setStats] = useState({ total: 0, sent: 0, failed: 0, scheduled: 0 });
  const [messages, setMessages] = useState<Message[]>([]);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [status, setStatus] = useState("Connecting to API...");
  const [busy, setBusy] = useState(false);
  const [contactForm, setContactForm] = useState({name:"",email:"",team:"General"});
  const [templateForm, setTemplateForm] = useState({name:"Reminder template",subject:"Reminder: {{ reminder_title }}",body:"Hello {{ name }},\\n\\nThis is a reminder for {{ reminder_title }}.\\n\\nRegards, Automation Team"});
  const [campaignForm, setCampaignForm] = useState({name:"Team reminder campaign",template_id:"",sender_email:"demo@example.com"});
  const [reminderForm, setReminderForm] = useState({title:"Follow-up reminder",contact_id:"",campaign_id:"",scheduled_at:"",recurrence:""});
  const [teamForm, setTeamForm] = useState({title:"Team update reminder",team:"",campaign_id:"",scheduled_at:"",recurrence:""});

  async function request(path:string, method="GET", body?:unknown) {
    const response = await fetch(API+path,{method,headers:{"Content-Type":"application/json"},...(body?{body:JSON.stringify(body)}:{})});
    if(!response.ok) { const data=await response.json().catch(()=>({})); throw new Error(data.detail || `Request failed (${response.status})`); }
    return response.json();
  }
  async function refresh() {
    try {
      const [s,m,c,t,ca,r] = await Promise.all([
        request("/stats"),request("/messages"),request("/contacts"),request("/templates"),request("/campaigns"),request("/reminders")
      ]);
      setStats(s);setMessages(m);setContacts(c);setTemplates(t);setCampaigns(ca);setReminders(r);setStatus("API connected");
      if(!campaignForm.template_id && t.length) setCampaignForm(v=>({...v,template_id:String(t[0].id)}));
      if(!reminderForm.contact_id && c.length) setReminderForm(v=>({...v,contact_id:String(c[0].id)}));
      if(!reminderForm.campaign_id && ca.length) setReminderForm(v=>({...v,campaign_id:String(ca[0].id)}));
      if(!teamForm.campaign_id && ca.length) setTeamForm(v=>({...v,campaign_id:String(ca[0].id)}));
      const teams = Array.from(new Set(c.map((item:Contact)=>item.team)));
      if(!teamForm.team && teams.length) setTeamForm(v=>({...v,team:teams[0]}));
    } catch { setStatus("API unavailable. Start FastAPI at http://localhost:8000"); }
  }
  useEffect(()=>{refresh();const timer=setInterval(refresh,5000);return()=>clearInterval(timer);},[]);
  async function act(fn:()=>Promise<unknown>, success:string) {
    setBusy(true);try{await fn();setStatus(success);await refresh();}catch(e){setStatus(e instanceof Error?e.message:"Something went wrong");}finally{setBusy(false);}
  }
  return <main className="wrap">
    <header className="head"><div><h1>Email Automation & Reminder System</h1><p className="muted">Create reminders, manage campaigns and monitor email activity.</p></div><button onClick={refresh}>Refresh data</button></header>
    <div className="status">{status}</div>
    <section className="grid">{Object.entries(stats).map(([key,value])=><div className="card" key={key}><div className="muted">{key.toUpperCase()}</div><div className="num">{value}</div></div>)}</section>

    <section className="panel"><h2>1. Add a contact</h2><div className="formgrid">
      <input placeholder="Full name" value={contactForm.name} onChange={e=>setContactForm({...contactForm,name:e.target.value})}/>
      <input placeholder="Email address" type="email" value={contactForm.email} onChange={e=>setContactForm({...contactForm,email:e.target.value})}/>
      <input placeholder="Team" value={contactForm.team} onChange={e=>setContactForm({...contactForm,team:e.target.value})}/>
      <button disabled={busy} onClick={()=>act(()=>request("/contacts","POST",contactForm),"Contact created")}>Add contact</button>
    </div></section>

    <section className="panel"><h2>2. Create an email template</h2><div className="formgrid">
      <input placeholder="Template name" value={templateForm.name} onChange={e=>setTemplateForm({...templateForm,name:e.target.value})}/>
      <input placeholder="Subject (Jinja placeholders supported)" value={templateForm.subject} onChange={e=>setTemplateForm({...templateForm,subject:e.target.value})}/>
      <textarea placeholder="Email body. Use {{ name }} and {{ reminder_title }}." rows={4} value={templateForm.body} onChange={e=>setTemplateForm({...templateForm,body:e.target.value})}/>
      <button disabled={busy} onClick={()=>act(()=>request("/templates","POST",templateForm),"Template created")}>Save template</button>
    </div><p className="muted">Personalization variables: {"{{ name }}"}, {"{{ email }}"}, {"{{ team }}"}, {"{{ reminder_title }}"}.</p></section>

    <section className="panel"><h2>3. Create a campaign</h2><div className="formgrid">
      <input placeholder="Campaign name" value={campaignForm.name} onChange={e=>setCampaignForm({...campaignForm,name:e.target.value})}/>
      <select value={campaignForm.template_id} onChange={e=>setCampaignForm({...campaignForm,template_id:e.target.value})}><option value="">Choose template</option>{templates.map(t=><option key={t.id} value={t.id}>{t.name} (#{t.id})</option>)}</select>
      <input type="email" placeholder="Sender email" value={campaignForm.sender_email} onChange={e=>setCampaignForm({...campaignForm,sender_email:e.target.value})}/>
      <button disabled={busy||!campaignForm.template_id} onClick={()=>act(()=>request("/campaigns","POST",{...campaignForm,template_id:Number(campaignForm.template_id),sender_name:"Automation Team"}),"Campaign created")}>Create campaign</button>
    </div></section>

    <section className="panel"><h2>4. Schedule a reminder</h2><div className="formgrid">
      <input placeholder="Reminder title" value={reminderForm.title} onChange={e=>setReminderForm({...reminderForm,title:e.target.value})}/>
      <select value={reminderForm.contact_id} onChange={e=>setReminderForm({...reminderForm,contact_id:e.target.value})}><option value="">Choose recipient</option>{contacts.map(c=><option key={c.id} value={c.id}>{c.name} — {c.email}</option>)}</select>
      <select value={reminderForm.campaign_id} onChange={e=>setReminderForm({...reminderForm,campaign_id:e.target.value})}><option value="">Choose campaign</option>{campaigns.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select>
      <input type="datetime-local" value={reminderForm.scheduled_at} onChange={e=>setReminderForm({...reminderForm,scheduled_at:e.target.value})}/>
      <input placeholder="Optional RRULE e.g. FREQ=WEEKLY;BYDAY=MO" value={reminderForm.recurrence} onChange={e=>setReminderForm({...reminderForm,recurrence:e.target.value})}/>
      <button disabled={busy||!reminderForm.contact_id||!reminderForm.campaign_id||!reminderForm.scheduled_at} onClick={()=>act(()=>request("/reminders","POST",{...reminderForm,contact_id:Number(reminderForm.contact_id),campaign_id:Number(reminderForm.campaign_id),scheduled_at:new Date(reminderForm.scheduled_at).toISOString()}),"Reminder scheduled")}>Schedule reminder</button>
    </div><p className="muted">Leave recurrence blank for a one-off reminder. For recurring reminders, use an RRULE such as FREQ=DAILY or FREQ=WEEKLY;BYDAY=MO.</p></section>

    <section className="panel"><h2>5. Schedule a team reminder</h2><div className="formgrid">
      <input placeholder="Team reminder title" value={teamForm.title} onChange={e=>setTeamForm({...teamForm,title:e.target.value})}/>
      <select value={teamForm.team} onChange={e=>setTeamForm({...teamForm,team:e.target.value})}><option value="">Choose team</option>{Array.from(new Set(contacts.map(c=>c.team))).map(team=><option key={team} value={team}>{team}</option>)}</select>
      <select value={teamForm.campaign_id} onChange={e=>setTeamForm({...teamForm,campaign_id:e.target.value})}><option value="">Choose campaign</option>{campaigns.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select>
      <input type="datetime-local" value={teamForm.scheduled_at} onChange={e=>setTeamForm({...teamForm,scheduled_at:e.target.value})}/>
      <input placeholder="Optional RRULE e.g. FREQ=WEEKLY" value={teamForm.recurrence} onChange={e=>setTeamForm({...teamForm,recurrence:e.target.value})}/>
      <button disabled={busy||!teamForm.team||!teamForm.campaign_id||!teamForm.scheduled_at} onClick={()=>act(()=>request("/team-reminders","POST",{...teamForm,campaign_id:Number(teamForm.campaign_id),scheduled_at:new Date(teamForm.scheduled_at).toISOString()}),"Team reminders scheduled")}>Schedule for team</button>
    </div><p className="muted">Creates one reminder per subscribed contact in the selected team.</p></section>

    <section className="panel"><div className="head"><h2>Scheduled reminders</h2><button disabled={busy} onClick={()=>act(()=>request("/process-due","POST",{}),"Due reminders processed")}>Process due now</button></div>
      <table><thead><tr><th>Title</th><th>Scheduled</th><th>Active</th></tr></thead><tbody>{reminders.map(r=><tr key={r.id}><td>{r.title}</td><td>{new Date(r.scheduled_at).toLocaleString()}</td><td>{String(r.active)}</td></tr>)}{!reminders.length&&<tr><td colSpan={3} className="muted">No reminders created yet.</td></tr>}</tbody></table>
    </section>

    <section className="panel"><h2>Email activity</h2><table><thead><tr><th>ID</th><th>Recipient</th><th>Subject</th><th>Status</th><th>Scheduled</th></tr></thead><tbody>{messages.map(m=><tr key={m.id}><td>{m.id}</td><td>{m.contact_email}</td><td>{m.subject}</td><td><span className={"pill "+m.status}>{m.status}</span>{m.error&&<small>{m.error}</small>}</td><td>{new Date(m.scheduled_at).toLocaleString()}</td></tr>)}{!messages.length&&<tr><td colSpan={5} className="muted">No messages recorded yet.</td></tr>}</tbody></table></section>
    <p className="muted">Dry-run is enabled by default. SMTP acceptance is not proof that an email reached the recipient's inbox.</p>
  </main>;
}
