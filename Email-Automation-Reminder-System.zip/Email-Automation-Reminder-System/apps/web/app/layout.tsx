import "./style.css";
export const metadata = { title: "Email Automation Dashboard", description: "Email campaign and reminder monitor" };
export default function RootLayout({children}:{children:React.ReactNode}) {
 return <html lang="en"><body>{children}</body></html>;
}
