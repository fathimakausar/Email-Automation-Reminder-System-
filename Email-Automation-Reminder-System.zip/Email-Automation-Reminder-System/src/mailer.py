import logging, smtplib
from email.message import EmailMessage
from src.config import DRY_RUN, SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM_NAME
log = logging.getLogger(__name__)

def send_email(to_email, subject, body, sender_email):
    if DRY_RUN:
        log.info("[DRY RUN] To=%s | Subject=%s", to_email, subject)
        return {"ok": True, "message_id": "DRY-RUN"}
    if not SMTP_USER or not SMTP_PASS:
        return {"ok": False, "error": "SMTP_USER and SMTP_PASS are required when DRY_RUN=false"}
    msg = EmailMessage()
    msg["Subject"], msg["From"], msg["To"] = subject, f"{SMTP_FROM_NAME} <{sender_email or SMTP_USER}>", to_email
    msg.set_content(body)
    try:
        with smtplib.SMTP_SSL(SMTP_HOST, SMTP_PORT, timeout=20) as smtp:
            smtp.login(SMTP_USER, SMTP_PASS)
            smtp.send_message(msg)
        return {"ok": True, "message_id": msg.get("Message-ID")}
    except Exception as exc:
        log.exception("SMTP send failed")
        return {"ok": False, "error": str(exc)}
