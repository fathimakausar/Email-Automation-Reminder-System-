from jinja2 import Environment, StrictUndefined

# Email bodies are plain text, so HTML auto-escaping is intentionally disabled.
env = Environment(undefined=StrictUndefined, autoescape=False)


def render(subject_template, body_template, context):
    subject = env.from_string(subject_template).render(**context)
    body = env.from_string(body_template).render(**context)
    return subject, body
