from datetime import datetime, timezone, timedelta
from dateutil.rrule import rrulestr
from sqlalchemy import select
from src.models import Reminder, Message, utcnow
from src.renderer import render
from src.mailer import send_email


def as_utc(value):
    """SQLite may return naive datetimes; this project stores all DB times as UTC."""
    if value is None:
        return None
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def plan_due(db, now=None):
    now = as_utc(now or datetime.now(timezone.utc))
    created = 0

    reminders = db.scalars(
        select(Reminder).where(Reminder.active.is_(True))
    ).all()

    for reminder in reminders:
        start = as_utc(reminder.scheduled_at)
        last = as_utc(reminder.last_fired_at)

        if reminder.recurrence:
            rule = rrulestr(reminder.recurrence, dtstart=start)
            next_fire = rule.after(last or (start - timedelta(seconds=1)), inc=True)
            next_fire = as_utc(next_fire)
        else:
            next_fire = start if last is None else None

        if next_fire and next_fire <= now:
            already_created = db.scalar(
                select(Message).where(
                    Message.reminder_id == reminder.id,
                    Message.scheduled_at == next_fire.replace(tzinfo=None),
                )
            )
            if not already_created and not reminder.contact.unsubscribed:
                campaign = reminder.campaign
                subject, body = render(
                    campaign.template.subject,
                    campaign.template.body,
                    {
                        "name": reminder.contact.name,
                        "email": reminder.contact.email,
                        "team": reminder.contact.team,
                        "reminder_title": reminder.title,
                    },
                )
                db.add(
                    Message(
                        reminder_id=reminder.id,
                        contact_email=reminder.contact.email,
                        subject=subject,
                        body=body,
                        scheduled_at=next_fire.replace(tzinfo=None),
                    )
                )
                created += 1

            reminder.last_fired_at = next_fire.replace(tzinfo=None)
            if not reminder.recurrence:
                reminder.active = False

    db.commit()
    return created


def dispatch_due(db, now=None):
    now = as_utc(now or datetime.now(timezone.utc))
    due_messages = db.scalars(
        select(Message).where(Message.status == "scheduled")
    ).all()

    processed = []
    for message in due_messages:
        scheduled = as_utc(message.scheduled_at)
        if scheduled > now:
            continue

        result = send_email(
            message.contact_email,
            message.subject,
            message.body,
            message.reminder.campaign.sender_email,
        )

        if result["ok"]:
            message.status = "sent"
            message.sent_at = utcnow().replace(tzinfo=None)
            message.provider_message_id = result.get("message_id")
        else:
            message.status = "failed"
            message.error = result.get("error", "Unknown sending error")

        processed.append({"id": message.id, "status": message.status})

    db.commit()
    return processed
