from datetime import datetime, timezone
from src.service import as_utc


def test_as_utc_converts_naive_datetime():
    value = as_utc(datetime(2026, 1, 1, 9, 0))
    assert value.tzinfo == timezone.utc


def test_as_utc_keeps_aware_instant():
    value = as_utc(datetime.fromisoformat("2026-01-01T09:00:00+05:30"))
    assert value.hour == 3 and value.minute == 30
