from src.renderer import render


def test_personalized_render():
    subject, body = render(
        "Hi {{ name }}",
        "Reminder for {{ reminder_title }} in {{ team }}",
        {"name": "Asha", "reminder_title": "training", "team": "HR"},
    )
    assert subject == "Hi Asha"
    assert body == "Reminder for training in HR"
